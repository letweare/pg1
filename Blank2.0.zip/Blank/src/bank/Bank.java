package bank;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import dbutils.*;
import user.*;
import dbutils .*;
public class Bank {

 int account;
 private static User user;
 public static void main (String[] args) throws IOException{
	 Bank b =new Bank();
	     b.login();
	     b.operate();
 }
 public void login () throws IOException{
	 DBUtils dbutil =DBUtils.getInstance();
	 System.out.println("��ӭ��������ϵͳ!");
	 while (true ){
		 Scanner in = new Scanner (System.in);
		 System.out.println("���������п����� ��");
		 String cardId = in.nextLine();
		 System.out.println("���������п�����:");
		 String cardPwd=in.nextLine();
      	  user =dbutil.getUser(cardId);
		 if(dbutil.getUsers().containsKey(cardId)&&user.getCardPwd().equals(cardPwd)){
			 System.out.println("��½�ɹ��� ��ӭ"+user.getuserName());
			 break;			 
		 }else {
			 System.out.println("���п��Ż��������");
			 continue;
		 }
		 
	 }
 }
 public void operate(){
	 Bank b =new Bank();
	 while (true ){
	 System.out.println("����������Ҫ���еĲ���");
	 System.out.println("��� ��1"+"\t"+"ȡ��: 2"+"\t"+"��� : 3"+"\t"+"�˳���0");
	 Scanner in =new Scanner(System.in);
	 String s= in.nextLine();
      if ("1".equals(s)||"2".equals(s)){
		 int num =0;
		 try {
			 System.out.println("�����ȡ��");
			 num=Integer.parseInt(in.nextLine());
		 }catch (Exception e){
			 System.out.println("����������");
			continue;
		 }
			
		 
        switch (s){
        case "1" : b.income(num); break;
        case "2" : b.takeout(num); break;
        }
        
	  } else if ("3".equals(s)) {
		  b.show();
	  }else if ("0".equals(s)){
		  
		b.exit();
		  System.out.println("�˳�ϵͳ��");
		  return ;
	  }else{
		 System.out.println("��������ȷѡ��0~3");
	  }
	 }
 }
 
 public void income (int num){
	 
	  user.setaccount(user.account()+num);
	  
 }
 public void  takeout (int num){
	
	 user.setaccount(user.account()-num);
	 
 }
 public void show (){
	 
	  System.out.println(user.account());
 } 
 public  void exit (){ 
	 
	  Set <String > userSet = DBUtils.users.keySet();
	  for(String cardId: userSet){
		  User u =(User ) DBUtils.users.get(cardId);
		  System.out.println(u.getCardId());
	  }
	  try {
	FileWriter	  writer =new FileWriter("DAt.txt");
	BufferedWriter bf = new BufferedWriter(writer);
	for (String cardId :userSet){
		User u =(User ) DBUtils.users.get(cardId);
		String ustring =u.getCardId()+","+u.getCardPwd()+","+u.getuserName()+","
				+u.getCall()+","+u.account()+"\r\n";
		writer.write(ustring);
		System.out.println(ustring);
	}    
	   bf .close();
	
	  }catch (IOException e1){
		  e1.printStackTrace();
	  } 
	
	
	  
 }
 
}
