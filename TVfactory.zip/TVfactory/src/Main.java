import XMLUtilTV .*;
import tv.*;
import tvfactory.*;
public class Main { 
	
	public static  void main ( String args[]){
     TV tv;
     String brandName = XMLUtilTV.getBrandName();
     tv = TVFactory.produceTV(brandName);
   // if(tv==null)   System.out.println("123");
     System.out.println(brandName);
        tv.play ();
       
}
}