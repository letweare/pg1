package car;

public class BMW implements Car{
    public double getRatio ()
    {
    	return 2.00;
    }
}
