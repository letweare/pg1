package gongsi;

public interface Gongsi {
	public double fee ();
	public void   pt  (String [] recordarry);
}
