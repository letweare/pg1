package dbutils;
import java.util.*;
import user.*;
public class DBUtils {
  private static DBUtils instance = null;
  private static HashMap <String ,User> users =new HashMap<String,User> ();
  private DBUtils (){
	  User u1 =new User();
	  u1.setCardId("01");
	  u1.setCarPwd("123456");
	  u1.setuserName("����");
	  u1.setCall("1000000001");
	  u1.setaccount(10000);
	  users.put(u1.getCardId(), u1);
	  ////////////////////////////////////
	  User u2 =new User ();
	  u2.setCardId("02");
	  u2.setCarPwd("123456");
	  u2.setuserName("����");
	  u2.setCall("1000000002");
	  u2.setaccount(100000);
	  users.put(u2.getCardId(),u2);
  }
  public static DBUtils getInstance (){
	  if(instance==null){
		  synchronized(DBUtils.class){
			  if(instance==null){
				  instance = new DBUtils();
			  }
		  }
	  }
	  return instance;
  }
 public   User getUser (String cardId){
	 User user =(User) users.get(cardId);
	 return user;
 }
 public HashMap <String,User> getUsers(){
	 return users;
 }
}
