package gongsi;
import java.util.*;
public class Dianxin implements Gongsi {
	public double  fee() {
		return 0.2;
	}
	public void pt (String [] recordField){
		
		
		
			System.out.println("Dx���У�"+recordField[0]);
			System.out.println("Dx���У�"+recordField[3]);
			System.out.println("Dxͨ����ʼʱ��"+new Date(Long.parseLong(recordField[1])));
			System.out.println("Dxͨ������ʱ��"+new Date(Long.parseLong(recordField[2])));
	
		
		System.out.println("This is dianxin printing !");
}
}