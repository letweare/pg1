package car;

public class Benz implements Car  {
   public double getRatio (){
	   return 1.00;
   }
}
