package dbutils;
import java.util.*;
import java.io.*;
import user.*;
public class DBUtils {
  private static DBUtils instance = null;
   public  static  HashMap <String ,User> users =new HashMap<String,User> ();
  private DBUtils () throws IOException{  
	  
	  FileReader    fs = new FileReader("data.txt");
	  int ch ;
	 BufferedReader fr = new BufferedReader (fs);
	 String str ; 
	  while ((str=fr.readLine())!=null){  
	      String  n;
	      n= str;
	      String x1 [] = n.split(",");
	      User u1 =new User();
	      u1.setCardId(x1[0]);
	      u1.setCarPwd(x1[1]);
	      u1.setuserName(x1[2]);
	      u1.setCall(x1[3]);
	      u1.setaccount(Integer.parseInt(x1[4]));
	      users.put(u1.getCardId(), u1);
		
	  }
	  fs.close();
	  
  }
  public static DBUtils getInstance () throws IOException{
	  if(instance==null){
		  synchronized(DBUtils.class){
			  if(instance==null){
				  instance = new DBUtils();
			  }
		  }
	  }
	  return instance;
  }
 public  static User getUser (String cardId){
	 Object value = users.get(cardId);
	 User u = (User)value;
	 return u;
 }
 public HashMap <String,User> getUsers(){
	 return users;
 } 
 

}
