package factory;

import car.*;

public interface factory {

	Car produceCar();
}
