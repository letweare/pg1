import java.util.*;
import printf.*;
import  Boss.*;
import gongsi.*;
import xm.*;
public class Tel {
   
	  public static void main (String [] args){
		  Telcomuser telcomuser= new Telcomuser("13800138000");
		  telcomuser .generateComunicateRecord();
		  telcomuser .printDetails();
	  }
}
class Telcomuser {
	private String phonenumber;
	private String callto;
	private StringBuffer communicationRecords;
	public Telcomuser (String phonenumber){
		this.phonenumber=phonenumber;
		this.communicationRecords=new StringBuffer();
		
	}
	void generateComunicateRecord(){
		int recordnum=new Random().nextInt(10);
		for(int i=0;i<=recordnum;i++){ 
		this.callto = getCallToPhoneNumber();
		long	timestart=System.currentTimeMillis()-new Random().nextInt(36000000);
		long   timeend=timestart+6000+new Random ().nextInt(600000);
		this.communicationRecords.append(this.phonenumber+","+timestart+","+timeend+","+this.callto+";");
		}
	} 
	private  String getCallToPhoneNumber (){
		return "1380372"+ String.valueOf(new Random().nextInt(10))
		                 +String.valueOf(new Random().nextInt(10))
		                 +String.valueOf(new Random().nextInt(10))
		                 +String.valueOf(new Random().nextInt(10));
	}
	public String accountFee(long timestart,long timeend){
		String  brandName=Xmu.getBrandName();
		Gongsi g ;
		g=Ceo.produce(brandName);
		double x=g.fee();
		double feePerMinute=x;
		int minutes =Math.round((timeend-timestart)/60000);
		double feeTotal =feePerMinute*minutes;
		return String.format("%.4f", feeTotal);
	}
	
	void printDetails(){  
	String allRecords=this.communicationRecords.toString();
		
	/*	String [] recordarry =allRecords.split(";");
		for (int i=0;i<recordarry.length;i++){
			String [] recordField =recordarry[i].split(",");
			System.out.println("���У�"+recordField[0]);
			System.out.println("���У�"+recordField[3]);
			System.out.println("ͨ����ʼʱ��"+new Date(Long.parseLong(recordField[1])));
			System.out.println("ͨ������ʱ��"+new Date(Long.parseLong(recordField[2])));
			System.out.println("�Ʒѣ�"
					+accountFee(Long.parseLong(recordField[1]),Long.parseLong(recordField[2]))
					+"Ԫ");
		Gongsi p;
		String brandName=Xmu.getBrandName();
		p=Ceo.produce(brandName);
		p.pt(allRecords);*/
		
		
		
		
		
		
		
		
		
		
		
		
		}
	}
	
	
}
















