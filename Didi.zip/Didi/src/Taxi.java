import xmlutil.*;

import car.*;
import factory.*;

public class Taxi {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		TaxiBase st=new TaxiBase();
		
		InPut input=new InPut(st);
		OutPut output=new OutPut(st);
		
		
		new Thread(output).start();
		Thread.sleep(1000);
		new Thread(input).start();
		
		
	}

}
class TaxiBase{
	
	private Benz[] car=new Benz[10];
	private int inPos,outPos;
	private int cnt;
	
	public TaxiBase(){
		
		BenzFactory carFactory=(BenzFactory)XmlutilCar.getBean();
		for(int i=0;i<10;i++){
			
			car[i]=carFactory.produceCar();
		}
		
		System.out.println("create 10  cars------");
	}
	
	public synchronized void put() {
		
		try {
			
		
		if(cnt==car.length) {
			
			this.wait();
		}
		
		System.out.println("����" + inPos + ", " + car[inPos].toString() + "���");
		inPos++;
		
		if(inPos==car.length)
			inPos=0;
		
		cnt++;
		Thread.sleep(100);
		this.notify();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void get() {
		
		try {
			
		
		if(cnt==0) {
			
			this.wait();
		}
		
		System.out.println("����" + outPos + ", " + car[outPos].toString() + "���⡣�Ʒѷ���" + car[outPos].getRatio());
		
		outPos++;
		if(outPos==car.length)
			outPos=0;
		cnt--;
		Thread.sleep(100);
		this.notify();
	}catch(Exception e) {
		
		e.printStackTrace();
	}
		
	}
	
	
}
class OutPut implements Runnable{
	
	private TaxiBase st;
	
	OutPut(TaxiBase st){
		this.st=st;
	}
	
	public void run() {
		
		while(true) {
			st.get();
		}
	}
	
}
class InPut implements Runnable{
	
	private TaxiBase st;
	//private int num;
	
	InPut(TaxiBase st){
		
		this.st=st;
	}
	
	public void run() {
		
		while(true) {
			
			st.put();
		}
	}
	
}
