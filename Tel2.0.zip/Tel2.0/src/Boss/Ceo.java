package Boss;

import gongsi.*;
public interface Ceo {
	public static Gongsi produce(String brand){
		if(brand.equals("Dianxin"))
		return new Dianxin();
if(brand.equals("Liantong"))
		return new Liantong();
return null;
}

}
