package user;

public class User {
  private String cardId;
  private String cardPwd;
  private String userName;
  private String Call;
  private int account;
  public String getCardId(){
	  return cardId;
  }
  public void setCardId (String cardId){
	  this.cardId=cardId;
  }
  public String getCardPwd(){
	  return cardPwd;
  }
  public void setCarPwd (String cardPwd){
	  this.cardPwd=cardPwd;
  }
  public String getuserName (){
	  return userName;
  }
  public void setuserName (String userName){
	  this.userName=userName;
  } 
 public String getCall ()
 {
	 return Call;
 }
  public void setCall(String Call){
	  this.Call=Call;
  }
  public int account (){
	  return account;
  }
  public void setaccount (int account){
	  this.account=account;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
