package tv;

public  class HisenseTV  implements  TV{
  
	public void play() {
		
		System.out.println("Thi is hinsense");
	}
}
