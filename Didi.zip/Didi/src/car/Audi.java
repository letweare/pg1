package car;

public class Audi implements Car {
   public double getRatio (){
	   return 3.00;
   }
}
