package tvfactory;
import tv.*;
public class TVFactory {
	
  public static TV produceTV (String brandName){
	  
	//  brandName="HaierTV";
	    
	   if(brandName.equals("HaierTV")) 
		   return  new HaierTV();
		   
	     if(brandName.equals("HinsenseTV"))
		   return  new HisenseTV();
	    
	  return null;
  }
}
