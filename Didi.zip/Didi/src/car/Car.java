package car;

public interface Car {
	public double getRatio ();
}